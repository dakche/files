# Egg Detector > 2024-09-15 5:32pm
https://universe.roboflow.com/robot-arm-pj9te/egg-detector-jhu1m

Provided by a Roboflow user
License: CC BY 4.0

